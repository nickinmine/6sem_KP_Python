create function trigger_auto_theme_close_date() returns trigger
    language plpgsql
as
$$
	BEGIN
	IF OLD.is_closed!=NEW.is_closed AND NEW.is_closed=true THEN
		NEW.close_date=now();
	END IF;
	RETURN NEW;
	END;
$$;

alter function trigger_auto_theme_close_date() owner to postgres;

