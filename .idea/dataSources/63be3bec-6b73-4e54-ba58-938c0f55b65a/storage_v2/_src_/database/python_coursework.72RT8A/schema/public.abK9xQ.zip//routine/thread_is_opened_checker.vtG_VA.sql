create function thread_is_opened_checker() returns trigger
    language plpgsql
as
$$
	declare
		res varchar;
	BEGIN
		IF (select is_closed from theme_thread where theme_id = new.theme_id) then
		raise exception 'Access denied. The theme is closed.';		
		END IF;
		return NEW;
	END;
$$;

alter function thread_is_opened_checker() owner to postgres;

